public interface Creature {
  public abstract void run();
}

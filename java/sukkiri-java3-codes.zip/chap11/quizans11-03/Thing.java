public interface Thing {
  double getWeight();
  void setWeight(double weight);
}

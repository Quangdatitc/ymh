public class Hero extends Character {
}

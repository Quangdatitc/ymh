public class Main {
  public static void main(String[] args) {
    Character c = new Character();
    Matango m = new Matango();
    c.attack(m);
  }
}

public class Coat {}

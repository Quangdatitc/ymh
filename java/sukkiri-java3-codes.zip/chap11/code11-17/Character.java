public abstract class Character {
  String name;
  int hp;
  public abstract void run();
  public abstract void attack(Matango m);
}

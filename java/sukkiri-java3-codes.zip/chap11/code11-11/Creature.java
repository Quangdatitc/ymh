public abstract class Creature {
  public abstract void run();
}

public class Weapon extends Item { /* … */ }

public class Main {
  public static void main(String[] args) {
    Weapon w = new Weapon();
  }
}

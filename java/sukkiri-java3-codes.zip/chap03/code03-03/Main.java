public class Main {
  public static void main(String[] args) {
    boolean tenki = true;    // ここでtrueかfalseを代入
    if (tenki == true) {
      System.out.println("洗濯をします");
      System.out.println("散歩にいきます");
    } else
      System.out.println("DVDを見ます");
  }
}

public class Main {
  public static void main(String[] args) {
    boolean doorClose = true;    // ここでtrueかfalseを代入
    while (doorClose == true) {
      System.out.println("ノックする");
      System.out.println("1分待つ");
    }            /* 3行目がtrueの場合、このプログラムを実行すると */
  }              /* 無限ループになるので、本文を参考に対応ください */
}

public class Main {
  public static void main(String[] args) {
    for (int i = 0; i < 3; i++) {
      System.out.print("現在" + (i + 1) + "周目→");
    }
  }
}

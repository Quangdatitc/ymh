public final class A extends Y {
  public void a() { System.out.print("Aa"); }
  public void b() { System.out.print("Ab"); }
  public void c() { System.out.print("Ac"); }
}

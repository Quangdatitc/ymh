public class B  extends Y {
  public void a() { System.out.print("Ba"); }
  public void b() { System.out.print("Bb"); }
  public void c() { System.out.print("Bc"); }
}

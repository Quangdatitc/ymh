public interface X { void a(); }

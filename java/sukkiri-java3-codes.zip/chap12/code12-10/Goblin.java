public class Goblin extends Monster {
  public void run() {
    System.out.println("ゴブリンは、腕をふって逃げ出した。");
  }
}

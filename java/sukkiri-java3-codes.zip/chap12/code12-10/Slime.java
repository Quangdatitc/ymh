public class Slime extends Monster {
  public void run() {
    System.out.println("スライムは、体をうねらせて逃げ出した。");
  }
}

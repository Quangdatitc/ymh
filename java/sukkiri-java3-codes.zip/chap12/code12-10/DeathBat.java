public class DeathBat extends Monster {
  public void run() {
    System.out.println("地獄コウモリは、羽ばたいて逃げ出した。");
  }
}

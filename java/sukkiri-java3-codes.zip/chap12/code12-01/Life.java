public interface Life { /* … */ }

public class Main {
  public static void main(String[] args) {
    Life lf = new Wizard();
  }
}

public class Main {
  public static void main(String[] args) {
    Slime s = new Slime(); Monster m = new Slime();
    s.run(); m.run();
  }
}

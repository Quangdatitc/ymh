public class Goblin {
  int hp;
  final int LEVEL = 12;
  char suffix;
  public void run() {
    System.out.println("ゴブリン" + this.suffix + "はダダダッと逃げ出した！");
  }
}

public class Main {
  public static void main(String[] args) {
    Hero h = new Hero();

    System.out.println(h.hp);
  }
}

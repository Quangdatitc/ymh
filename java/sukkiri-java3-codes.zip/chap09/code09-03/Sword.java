// まず、Swordクラスを定義しておく
public class Sword {
  String name;
  int damage;
}

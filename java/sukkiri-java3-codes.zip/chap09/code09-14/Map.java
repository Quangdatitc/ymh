public class Map {
  /* ： */
  public Map() {
  }
}

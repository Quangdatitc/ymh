public class Main {
  public static void main(String[] args) {
    Hero h = new Hero("ミナト");
    
    System.out.println(h.hp);
    System.out.println(h.name);
  }
}

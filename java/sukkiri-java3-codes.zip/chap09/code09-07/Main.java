public class Main {
  public static void main(String[] args) {
    String s = new String("こんにちは");
    System.out.println(s);
  }
}

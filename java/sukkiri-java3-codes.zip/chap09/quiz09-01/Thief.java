public class Thief {
  String name;
  int hp;
  int mp;
}

public class Main{
  public static void main(String[] args) {
    Hero h;
    h = new Hero();
    h.hp = 100;
  }
}

public class Main {
  public static void main(String[] args) {
    int a = 3; int b = 5;
    int c = a * b;
    System.out.println("縦幅3横幅5の長方形の面積は、" + c);
  }
}

public class Main {
  public static void main(String[] args) {
    int age = 20;
    System.out.println("私の年齢は" + age);
    age = 31;
    System.out.println("…いや、本当の年齢は" + age);
  }
}

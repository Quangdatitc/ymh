public class Main {
  public static void main(String[] args) {
    int age;
    age = 30;
    System.out.println(age);
  }
}

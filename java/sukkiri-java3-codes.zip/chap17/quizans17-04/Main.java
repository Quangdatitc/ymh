import java.io.IOException;

public class Main {
  public static void main(String[] args) throws IOException {
    System.out.println("プログラムが起動しました");
    throw new IOException();
  }
}

public class Main {
  public static void main(String[] args) {
    /* ここに勇者への指示を書いていく */
  }
}

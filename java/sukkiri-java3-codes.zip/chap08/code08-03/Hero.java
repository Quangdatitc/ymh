public class Hero {
}

public class Cleric {
}

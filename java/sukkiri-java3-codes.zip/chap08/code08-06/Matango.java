public class Matango {
  int hp;
  final int LEVEL = 10;
}

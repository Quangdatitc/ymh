public class Main {
  public static void main(String[] args) {
    // 1.勇者を生成
    Hero h = new Hero();
  }
}

public class Main {
  public static void main(String[] args) {
    // （以下の内容をJavaで記述していく）
    // 勇者よ、この仮想世界に生まれよ！
    // お化けキノコよ、この仮想世界に生まれよ！
    // 勇者よ、戦え！
    // お化けキノコよ、逃げろ！
  }
}

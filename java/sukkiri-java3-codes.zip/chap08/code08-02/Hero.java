public class Hero {
  String name;
  int hp;
  public void attack() {/* … */}
  public void sleep() {/* … */}
  public void sit(int sec) {/* … */}
  public void slip() {/* … */}
  public void run() {/* … */}
}

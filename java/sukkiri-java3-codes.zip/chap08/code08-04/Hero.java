public class Hero {
  String name;  // 名前の宣言
  int hp;       // HPの宣言
}

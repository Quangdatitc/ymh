public class Matango {
  int hp;
  int level = 10;
}

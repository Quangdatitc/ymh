public class Main {
  public static void main(String[] args) {
    String age = "31";
    int n = Integer.parseInt(age);
    System.out.println("あなたは来年、" + (n + 1) + "歳になりますね。");
  }
}

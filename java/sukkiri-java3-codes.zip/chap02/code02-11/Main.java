public class Main {
  public static void main(String[] args) {
    String name = "すがわら";
    System.out.print("私の名前は");
    System.out.print(name);
    System.out.print("です");
  }
}

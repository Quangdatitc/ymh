public class Main {
  public static void main(String[] args) {
    int i = 3.2;
  }
}

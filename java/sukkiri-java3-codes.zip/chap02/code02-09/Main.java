public class Main {
  public static void main(String[] args) {
    String msg = "私の年齢は" + 23;
    System.out.println(msg);
  }
}

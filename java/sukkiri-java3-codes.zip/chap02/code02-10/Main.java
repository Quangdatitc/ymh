public class Main {
  public static void main(String[] args) {
    String name = "すがわら";
    String message;
    message = name + "さん、こんにちは";
    System.out.println(message);
  }
}

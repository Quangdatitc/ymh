public class Main {
  public static void main(String[] args) {
    int x = 5;
    int y = 10;
    String ans = "x+yは" + x + y;
    System.out.println(ans);
  }
}

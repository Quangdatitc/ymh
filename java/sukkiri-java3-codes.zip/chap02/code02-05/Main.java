public class Main {
  public static void main(String[] args) {
    float f = 3;
    double d = f;
    System.out.println(f);
    System.out.println(d);
  }
}

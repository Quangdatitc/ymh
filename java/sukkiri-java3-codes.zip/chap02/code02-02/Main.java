public class Main {
  public static void main(String[] args) {
    System.out.println("私の好きな記号は二重引用符（"）です");
  }
}

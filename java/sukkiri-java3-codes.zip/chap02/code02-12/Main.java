public class Main {
  public static void main(String[] args) {
    int a = 5;
    int b = 3;
    int m = Math.max(a, b);
    System.out.println("比較実験：" + a + "と" + b + "とで大きいほうは…" + m);
  }
}

public class Main {
  public static void main(String[] args) {
    int age = (int)3.2;
    System.out.println(age);
  }
}

public class Printer {
  public void printAnything(Object o) {
    // 何型でもいいから、引数を1つ受け取り画面に表示
    System.out.println(o.toString());
  }
}

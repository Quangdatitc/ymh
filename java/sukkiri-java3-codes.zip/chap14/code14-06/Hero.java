public class Hero {
  String name;
  int hp;
  /* … */
  public String toString() {
    return "名前：" + this.name + "／HP：" + this.hp;
  }
}

public class Main {
  public static void main(String[] args) {
    Object o1 = new Empty();
    Object o2 = new Hero();
    Object o3 = "こんにちは";
  }
}

public class Hero {
  String name;
  int hp;
  /* … */
}

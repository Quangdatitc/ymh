public class Empty {}

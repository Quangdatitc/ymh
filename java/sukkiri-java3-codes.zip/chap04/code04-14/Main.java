public class Main {
  public static void main(String[] args) {
    int[] scores = {20, 30, 40, 50, 80};
    for (int value : scores) {
      System.out.println(value);
    }
  }
}

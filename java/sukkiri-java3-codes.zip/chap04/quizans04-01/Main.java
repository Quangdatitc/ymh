public class Main {
  public static void main(String[] args) {
    int[] points = new int[4];
    double[] weights = new double[5];
    boolean[] answers = new boolean[3];
    String[] names = new String[3];
  }
}

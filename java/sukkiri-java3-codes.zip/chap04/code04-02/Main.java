public class Main {
  public static void main(String[] args) {
    int[] scores;
    scores = new int[5];
  }
}

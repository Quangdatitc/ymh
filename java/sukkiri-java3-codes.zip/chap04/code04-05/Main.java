public class Main {
  public static void main(String[] args) {
    int[] scores;
    scores = new int[5];
    scores[1] = 30;
    System.out.println(scores[1]);
  }
}

public class Main {
  public static void main(String[] args) {
    int[] scores = new int[5];
    int num = scores.length;
    System.out.println("要素の数: " + num);
  }
}

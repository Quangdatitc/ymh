public class Main {
  public static void main(String[] args) {
    int[] scores = new int[5];
    System.out.println(scores[0]);
  }
}

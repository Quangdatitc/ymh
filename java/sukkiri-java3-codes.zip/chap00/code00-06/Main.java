public class Main {
  public static void main(String[] args) {
    System.out.println("すがわら");
    System.out.println("31歳です");
    System.out.println("お酒が好きです");
    System.out.println("31 + 31の計算をします");
    System.out.println(31 + 31);
    int x;
    x = 6;
    System.out.println(x * x * 3.14);
  }
}

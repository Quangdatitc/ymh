public class Main {
  public static void main(String[] args) {
    System.out.println("すがわら");
    System.out.println("31歳です");
    System.out.println("お酒が好きです");
  }
}

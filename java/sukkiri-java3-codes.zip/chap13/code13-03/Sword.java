public class Sword {
  String name;
  int damage;
}
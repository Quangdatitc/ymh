public class Wand {
  private String name;     // 杖の名前
  private double power;    // 杖の魔力
}

public class Inn {
  public void checkIn(Hero h) {
    h.hp = -100;
  }
}

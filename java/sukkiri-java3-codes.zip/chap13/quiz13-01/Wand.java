public class Wand {
  String name;     // 杖の名前
  double power;    // 杖の魔力
}

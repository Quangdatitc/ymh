public class Main {
  public static void hello() {
    System.out.println("湊さん、こんにちは");
  }
}

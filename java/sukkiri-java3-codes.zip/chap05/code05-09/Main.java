public class Main {
  public static int sample() {
    // :
    return 1;
    int x = 10;
  }
}

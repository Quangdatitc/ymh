package comment;

public class Zenhan {
  public static void doWarusa() {
    System.out.println("きなこでござる。食えませんがの。");
  }
  public static void doTogame() {
    System.out.println("この老いぼれの目はごまかせませんぞ。");
  }
}

import comment.Zenhan;

public class Main {
  public static void main(String[] args) throws Exception {
    Zenhan.doWarusa();
    Zenhan.doTogame();
    comment.Kouhan.callDeae();
    comment.Kouhan.showMondokoro();
  }
}

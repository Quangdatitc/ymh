import importlib
import excel_read
importlib.reload(excel_read)
import os
import xlwings as xw
#統計処理と画像化
main = excel_read.excel_read_data()
main.input()

#マクロ起動。画像を貼り付け処理
strPath = os.getcwd()
fileName = os.path.join(strPath, "パワーポイント操作.xlsm")
App = xw.App()
wb = App.books.open(fileName)
macro=wb.macro("PorerpointOperation")
macro()
wb.close()
App.quit()
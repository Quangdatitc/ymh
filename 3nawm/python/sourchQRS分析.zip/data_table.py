import importlib
import statistics_output
importlib.reload(statistics_output)
from matplotlib import pyplot as pyp
from scipy.stats import norm
import numpy as np
from PIL import Image, ImageDraw, ImageFont
pyp.rcParams['font.family'] = 'MS Gothic'
output = statistics_output.statistics_data()

#受け取ったデータからグラフを作成するクラス
class image_fail_output:
    
    #通常のヒストグラム作成
    def standard_histogramDisplay(self, existing_product, test_sample, average_e_data, stdev_e_data, cp_e_data, cpk_e_data, average_t_data, stdev_t_data, cp_t_data, cpk_t_data, lower_limit_standard, upper_limit_standard, outputPath, outputName):
        #既存ラベル作成
        n_data = "n = " + str(len(existing_product))
        Xber = "Xber = " + str(output.round_3off(average_e_data))
        s = "s = " + str(output.round_3off(stdev_e_data))
        cp_e_data = "Cp = " + str(output.round_3off(cp_e_data))
        cpk_e_data = "Cpk = " + str(output.round_3off(cpk_e_data))
        label_e = n_data + "\n" + s + "\n" + Xber + "\n" + cp_e_data + "\n" + cpk_e_data
        #評価ラベル作成
        n_data2 = "n = " + str(len(test_sample))
        Xber2 = "Xber = " + str(output.round_3off(average_t_data))
        s2 = "s = " + str(output.round_3off(stdev_t_data))
        cp_t_data = "Cp = " + str(output.round_3off(cp_t_data))
        cpk_t_data = "Cpk = " + str(output.round_3off(cpk_t_data))
        label_t = n_data2 + "\n" + s2 + "\n" + Xber2 + "\n" + cp_t_data + "\n" + cpk_t_data
        
        #1次元データによるヒストグラフ表示
        fig = pyp.figure()
        fig.suptitle("ヒストグラム上：現行品 / ヒストグラム下：評価品\n" + outputName,fontsize=14,weight='extra bold')
        area1 = fig.add_subplot(211)
        area2 = fig.add_subplot(212)
                #(配列データ, bins=階級数, edgecolor=棒枠線の色,　rwidth=棒間隔, density=正規化)
        area1.hist(existing_product, bins=output.sturges_rule(len(existing_product)), edgecolor="black", rwidth=1, density=True)
        #xs = (bins[:-1] + bins[1:])/2
        #ys = n.astype(float)
        xmin, xmax = min(existing_product), max(existing_product)               #データの最小値、最大値
        area1.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)  #横軸表示設定
        # area1.set_ylim(0, 0.5)                                                 #縦軸設定設定
        #x_axis = np.linspace(xmin * 0.95, xmax * 1.05, 100)                     #最小値から最大値の等間隔の配列を100個作成
        # x_axis = np.linspace(xmin * 0.90, xmax * 1.10, 100)                     #最小値から最大値の等間隔の配列を100個作成
        x_axis = np.linspace(xmin * 0.80, xmax * 1.20, 100)                     #最小値から最大値の等間隔の配列を100個作成
        pdf = norm.pdf(x_axis, loc=average_e_data, scale=stdev_e_data)          #確率密度(正規分布)を作成
        area1.vlines(average_e_data, 0, 1, colors="orange")                     #縦軸(Xber)
        area1.vlines(lower_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準下限)
        area1.vlines(upper_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準上限)
        area1.plot(x_axis, pdf, label=label_e)                                  #正規分布曲線を反映
        area1.legend(loc = 'upper left')                                        #凡例
        #for x, y in zip(xs, ys):
            #area1.text(x, y, str(y), horizontalalignment="center")
        
        area2.hist(test_sample, bins=output.sturges_rule(len(test_sample)), edgecolor="black", rwidth=1, density=True)
        xmin2, xmax2 = min(test_sample), max(test_sample)                       #データの最小値、最大値
        area2.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)  #横軸表示設定
        # area2.set_ylim(0, 0.5)                                                 #縦軸表示設定
        #x_axis2 = np.linspace(xmin2 * 0.95, xmax2 * 1.05, 100)                  #最小値から最大値の等間隔の配列を100個作成
        # x_axis2 = np.linspace(xmin2 * 0.90, xmax2 * 1.10, 100)                  #最小値から最大値の等間隔の配列を100個作成
        x_axis2 = np.linspace(xmin2 * 0.80, xmax2 * 1.20, 100)                  #最小値から最大値の等間隔の配列を100個作成
        pdf2 = norm.pdf(x_axis2, loc=average_t_data, scale=stdev_t_data)        #確率密度(正規分布)を作成
        area2.vlines(average_t_data, 0, 1, colors="orange")                     #縦軸(Xber)
        area2.vlines(lower_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準下限)
        area2.vlines(upper_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準上限)
        area2.plot(x_axis2, pdf2, label=label_t)                                #正規分布曲線
        area2.legend(loc = 'upper left')                                        #凡例
        
        #pyp.show()
        fig.savefig(outputPath)

    #既存のみのヒストグラム作成
    def existing_histogramDisplay(self, existing_product, average_e_data, stdev_e_data, cp_e_data, cpk_e_data, lower_limit_standard, upper_limit_standard, outputPath, outputName):
        #既存ラベル作成
        n_data_E2 = "n = " + str(len(existing_product))
        Xber_E2 = "Xber = " + str(output.round_3off(average_e_data))
        s_E2 = "s = " + str(output.round_3off(stdev_e_data))
        cp_e_data_E2 = "Cp = " + str(output.round_3off(cp_e_data))
        cpk_e_data_E2 = "Cpk = " + str(output.round_3off(cpk_e_data))
        label_e = n_data_E2 + "\n" + s_E2 + "\n" + Xber_E2 + "\n" + cp_e_data_E2 + "\n" + cpk_e_data_E2       #=>cp and cpk not put in
        
        #1次元データによるヒストグラム表示
        fig_E2 = pyp.figure()
        fig_E2.suptitle("ヒストグラム：現行品 / " + outputName,fontsize=14,weight = 'extra bold')
        area_E2 = fig_E2.add_subplot(111)
                #(配列データ, bins=階級数, edgecolor=棒枠線の色,　rwidth=棒間隔, density=正規化)
        area_E2.hist(existing_product, bins=output.sturges_rule(len(existing_product)), edgecolor="black", rwidth=1, density=True)
        xmin_E2, xmax_E2 = min(existing_product), max(existing_product)             #データの最小値、最大値
        area_E2.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)    #横軸表示設定
        #area_E2.set_ylim(0, 0)                                                     #縦軸表示設定
        # x_axis_E2 = np.linspace(xmin_E2 * 0.95, xmax_E2 * 1.05, 100)                #最小値から最大値の等間隔の配列を100個作成
        # x_axis_E2 = np.linspace(xmin_E2 * 0.90, xmax_E2 * 1.10, 100)                #最小値から最大値の等間隔の配列を100個作成
        x_axis_E2 = np.linspace(xmin_E2 * 0.80, xmax_E2 * 1.20, 100)                #最小値から最大値の等間隔の配列を100個作成
        pdf_E2 = norm.pdf(x_axis_E2, loc=average_e_data, scale=stdev_e_data)        #確率密度(正規分布)を作成
        area_E2.vlines(average_e_data, 0, 1, colors="orange")                       #縦軸(Xber)
        area_E2.vlines(lower_limit_standard, 0, 1, colors="blue")                   #縦軸(検査基準下限)
        area_E2.vlines(upper_limit_standard, 0, 1, colors="blue")                   #縦軸(検査基準上限)
        area_E2.plot(x_axis_E2, pdf_E2, label=label_e)                              #正規分布曲線を反映
        area_E2.legend(loc = 'upper left')                                          #凡例
        
        #pyp.show()
        fig_E2.savefig(outputPath)
        
    #評価のみのヒストグラム作成
    def test_histogramDisplay(self, test_sample, average_t_data, stdev_t_data, cp_t_data ,cpk_t_data, lower_limit_standard, upper_limit_standard, outputPath, outputName):
        #評価ラベル作成
        n_data_T2 = "n = " + str(len(test_sample))
        Xber_T2 = "Xber = " + str(output.round_3off(average_t_data))
        s_T2 = "s = " + str(output.round_3off(stdev_t_data))
        cp_t_data_T2 = "Cp = " + str(output.round_3off(cp_t_data))
        cpk_t_data_T2 = "Cpk = " + str(output.round_3off(cpk_t_data))
        label_t = n_data_T2 + "\n" + s_T2 + "\n" + Xber_T2 #+ "\n" + cp_t_data_T2 + "\n" + cpk_t_data_T2
        
        #1次元データによるヒストグラム表示
        fig_T2 = pyp.figure()
        fig_T2.suptitle("ヒストグラム：評価品 / " + outputName,fontsize=14,weight = 'extra bold')
        area_T2 = fig_T2.add_subplot(111)
                #(配列データ, bins=階級数, edgecolor=棒枠線の色,　rwidth=棒間隔, density=正規化)
        area_T2.hist(test_sample, bins=output.sturges_rule(len(test_sample)), edgecolor="black", rwidth=1, density=True)
        xmin_T2, xmax_T2 = min(test_sample), max(test_sample)                       #グラフ内の表示範囲
        area_T2.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)    #横軸表示設定
        #area_T2.set_ylim(0, 0)                                                     #縦軸表示設定
        # x_axis_T2 = np.linspace(xmin_T2 * 0.95, xmax_T2 * 1.05, 100)                #最小値から最大値の等間隔の配列を100個作成
        # x_axis_T2 = np.linspace(xmin_T2 * 0.90, xmax_T2 * 1.10, 100)                #最小値から最大値の等間隔の配列を100個作成
        x_axis_T2 = np.linspace(xmin_T2 * 0.80, xmax_T2 * 1.20, 100)                #最小値から最大値の等間隔の配列を100個作成
        pdf_T2 = norm.pdf(x_axis_T2, loc=average_t_data, scale=stdev_t_data)        #確率密度(正規分布)を作成
        area_T2.vlines(average_t_data, 0, 1, colors="orange")                       #縦軸(Xber)
        area_T2.vlines(lower_limit_standard, 0, 1, colors="blue")                   #縦軸(検査基準下限)
        area_T2.vlines(upper_limit_standard, 0, 1, colors="blue")                   #縦軸(検査基準上限)
        area_T2.plot(x_axis_T2, pdf_T2, label=label_t)                              #正規分布曲線
        area_T2.legend(loc = 'upper left')                                          #凡例
        
        #pyp.show()
        fig_T2.savefig(outputPath)
        
    #急いでいた為、雑に作成しています。ごめんなさい
    def table_display(self, existing_product, test_sample, average_e_data, stdev_e_data, cp_e_data, cpk_e_data, average_t_data, stdev_t_data, cp_t_data, cpk_t_data, lower_limit_standard, upper_limit_standard, outputPath, outputName, df, text,df_f,text2):
        #fig, ax = pyp.subplots(figsize=(5, 5))
        
        #既存ラベル作成
        n_data = "n = " + str(len(existing_product))
        Xber = "Xber = " + str(output.round_3off(average_e_data))
        s = "s = " + str(output.round_3off(stdev_e_data))
        cp_e_data = "Cp = " + str(output.round_3off(cp_e_data))
        cpk_e_data = "Cpk = " + str(output.round_3off(cpk_e_data))
        label_e = n_data + "\n" + s + "\n" + Xber# + "\n" + cp_e_data + "\n" + cpk_e_data 
        #評価ラベル作成
        n_data2 = "n = " + str(len(test_sample))
        Xber2 = "Xber = " + str(output.round_3off(average_t_data))
        s2 = "s = " + str(output.round_3off(stdev_t_data))
        cp_t_data = "Cp = " + str(output.round_3off(cp_t_data))
        cpk_t_data = "Cpk = " + str(output.round_3off(cpk_t_data))
        label_t = n_data2 + "\n" + s2 + "\n" + Xber2# + "\n" + cp_t_data + "\n" + cpk_t_data
        
        #1次元データによるヒストグラフ表示
        fig = pyp.figure(figsize=(15, 6))
        fig.tight_layout(rect=[0,0,1,0.96])
        gs = fig.add_gridspec(2, 3)
        fig.suptitle("ヒストグラム上：現行品/ヒストグラム下：評価品\n" + outputName, x=0.2, y=0.96, fontsize=14,weight = 'extra bold')
        area1 = fig.add_subplot(gs[0, 0:1])
        area2 = fig.add_subplot(gs[1, 0:1])
                #(配列データ, bins=階級数, edgecolor=棒枠線の色,　rwidth=棒間隔, density=正規化)
        area1.hist(existing_product, bins=output.sturges_rule(len(existing_product)), edgecolor="black", rwidth=1, density=True)
        #xs = (bins[:-1] + bins[1:])/2
        #ys = n.astype(float)
        xmin, xmax = min(existing_product), max(existing_product)               #データの最小値、最大値
        area1.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)  #横軸表示設定
        #area1.set_ylim(0, 0.5)                                                 #縦軸設定設定
        # x_axis = np.linspace(xmin * 0.95, xmax * 1.05, 100)                     #最小値から最大値の等間隔の配列を100個作成
        # x_axis = np.linspace(xmin * 0.90, xmax * 1.10, 100)                     #最小値から最大値の等間隔の配列を100個作成
        x_axis = np.linspace(xmin * 0.80, xmax * 1.20, 100)                     #最小値から最大値の等間隔の配列を100個作成
        pdf = norm.pdf(x_axis, loc=average_e_data, scale=stdev_e_data)          #確率密度(正規分布)を作成
        area1.vlines(average_e_data, 0, 1, colors="orange")                     #縦軸(Xber)
        area1.vlines(lower_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準下限)
        area1.vlines(upper_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準上限)
        area1.plot(x_axis, pdf, label=label_e)                                  #正規分布曲線を反映
        area1.legend(loc = 'upper left')                                        #凡例
        #for x, y in zip(xs, ys):
            #area1.text(x, y, str(y), horizontalalignment="center")
        
        area2.hist(test_sample, bins=output.sturges_rule(len(test_sample)), edgecolor="black", rwidth=1, density=True)
        xmin2, xmax2 = min(test_sample), max(test_sample)                       #データの最小値、最大値
        area2.set_xlim(lower_limit_standard * 0.8, upper_limit_standard * 1.2)  #横軸表示設定
        #area2.set_ylim(0, 0.5)                                                 #縦軸表示設定
        # x_axis2 = np.linspace(xmin2 * 0.95, xmax2 * 1.05, 100)                  #最小値から最大値の等間隔の配列を100個作成
        # x_axis2 = np.linspace(xmin2 * 0.90, xmax2 * 1.10, 100)                  #最小値から最大値の等間隔の配列を100個作成
        x_axis2 = np.linspace(xmin2 * 0.80, xmax2 * 1.20, 100)                  #最小値から最大値の等間隔の配列を100個作成
        pdf2 = norm.pdf(x_axis2, loc=average_t_data, scale=stdev_t_data)        #確率密度(正規分布)を作成
        area2.vlines(average_t_data, 0, 1, colors="orange")                     #縦軸(Xber)
        area2.vlines(lower_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準下限)
        area2.vlines(upper_limit_standard, 0, 1, colors="blue")                 #縦軸(検査基準上限)
        area2.plot(x_axis2, pdf2, label=label_t)                                #正規分布曲線
        area2.legend(loc = 'upper left')                                        #凡例

        ax = fig.add_subplot(gs[:, 1:2])
        ax.axis("off")
        space=1.11
        textsp=text.split("\n")
        for tit_text in textsp:
            space=space-0.035
            if "棄却される" in tit_text:
                ax.text(0.5,space,tit_text,color=('red'),fontsize=10,transform=ax.transAxes,ha='center',fontname='Meiryo')
            else:
                ax.text(0.5,space,tit_text,color=('black'),fontsize=10,transform=ax.transAxes,ha='center',fontname='Meiryo')
        #ax.set_title(label=newtext, fontsize=10)
        ax.table(cellText=df.values,
                fontsize=10,
                loc="bottom",#center
                bbox=[0,0,1,1])
        
        ax1 = fig.add_subplot(gs[:, 2:3])
        ax1.axis("off")
        spacex=1.11
        textsp=text2.split("\n")
        for tit_text in textsp:
            spacex=spacex-0.035
            if "棄却される" in tit_text:
                ax1.text(0.5,spacex,tit_text,color=('red'),fontsize=10,transform=ax1.transAxes,ha='center',fontname='Meiryo')
            else:
                ax1.text(0.5,spacex,tit_text,color=('black'),fontsize=10,transform=ax1.transAxes,ha='center',fontname='Meiryo')
        #ax1.set_title(label=text2, fontsize=10)
        ax1.table(cellText=df_f.values,
                fontsize=10,
                loc="bottom",#center
                bbox=[0,0,1,1])
        #fig.show()
        fig.savefig(outputPath)
    def capability_table(self,cp_e_data,cpk_e_data,cp_t_data,cpk_t_data,Outputpath):
        cp_e_data =  str(output.round_3off(cp_e_data))
        cpk_e_data =  str(output.round_3off(cpk_e_data))       
        cp_t_data = str(output.round_3off(cp_t_data))
        cpk_t_data =  str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",cp_e_data],
            ["CpK", cpk_e_data],
            ["評価品", ""],
            ["Cp", cp_t_data],
            ["Cpk",cpk_t_data]
        ]
        merged_cells=[0,3]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data]
        if float(cp_e_data) < 1.33:
            red_cells.append(str(cp_e_data))

        if float(cp_t_data) < 1.33:
            red_cells.append(str(cp_t_data))

        if float(cpk_e_data) < 1:
            red_cells.append(str(cpk_e_data))

        if float(cpk_t_data) < 1:
            red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(Outputpath)

    def capability_table_top(self,max_cpk_e_data,max_cpk_t_data,OutputPath):
        cp_e_data =  str(output.round_3off(max_cpk_e_data))
        cpk_e_data =  ""#str(output.round_3off(cpk_e_data)) ""      
        cp_t_data = str(output.round_3off(max_cpk_t_data))
        cpk_t_data =  ""#str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",cp_e_data],
            
            ["評価品", ""],
            ["Cp", cp_t_data]
            
        ]
        merged_cells=[0,2]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data]
        if float(cp_e_data) < 1.00:
            red_cells.append(str(cp_e_data))

        if float(cp_t_data) < 1.00:
            red_cells.append(str(cp_t_data))

        #if float(cpk_e_data) < 1:
        #    red_cells.append(str(cpk_e_data))

        #if float(cpk_t_data) < 1:
        #    red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(OutputPath)

    def capability_table_bot(self,min_cpk_e_data,min_cpk_t_data,OutputPath):
        cp_e_data =  str(output.round_3off(min_cpk_e_data))
        cpk_e_data =  ""#str(output.round_3off(cpk_e_data)) ""      
        cp_t_data = str(output.round_3off(min_cpk_t_data))
        cpk_t_data =  ""#str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",cp_e_data],
            
            ["評価品", ""],
            ["Cp", cp_t_data]
        ]
        merged_cells=[0,2]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data]
        if float(cp_e_data) < 1.00:
            red_cells.append(str(cp_e_data))

        if float(cp_t_data) < 1.00:
            red_cells.append(str(cp_t_data))

        #if float(cpk_e_data) < 1:
        #    red_cells.append(str(cpk_e_data))

        #if float(cpk_t_data) < 1:
        #    red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(OutputPath)
    def katagawa_table_top(self,max_cpk_t_data,OutputPath):
        #cp_e_data =  str(output.round_3off(max_cpk_e_data))
        cpk_e_data =  ""#str(output.round_3off(cpk_e_data)) ""      
        cp_t_data = str(output.round_3off(max_cpk_t_data))
        cpk_t_data =  ""#str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",""],
            
            ["評価品", ""],
            ["Cp", cp_t_data]
            
        ]
        merged_cells=[0,2]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data])
        if float(cp_t_data) < 1.00:
            red_cells.append(str(cp_t_data))

        #if float(cpk_e_data) < 1:
        #    red_cells.append(str(cpk_e_data))

        #if float(cpk_t_data) < 1:
        #    red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(OutputPath)

    def katagawa_table_bot(self,min_cpk_t_data,OutputPath):
        #cp_e_data =  str(output.round_3off(min_cpk_e_data))
        cpk_e_data =  ""#str(output.round_3off(cpk_e_data)) ""      
        cp_t_data = str(output.round_3off(min_cpk_t_data))
        cpk_t_data =  ""#str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",""],
            
            ["評価品", ""],
            ["Cp", cp_t_data]
        ]
        merged_cells=[0,2]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data]

        if float(cp_t_data) < 1.00:
            red_cells.append(str(cp_t_data))

        #if float(cpk_e_data) < 1:
        #    red_cells.append(str(cpk_e_data))

        #if float(cpk_t_data) < 1:
        #    red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(OutputPath)
    def katagawa_table(self,cp_t_data,cpk_t_data,Outputpath):     
        cp_t_data = str(output.round_3off(cp_t_data))
        cpk_t_data =  str(output.round_3off(cpk_t_data))      
        # Create table data
        table_data = [
            ["現行品", ""],
            ["Cp",""],
            ["CpK", ""],
            ["評価品", ""],
            ["Cp", cp_t_data],
            ["Cpk",cpk_t_data]
        ]
        merged_cells=[0,3]# Rows to merge, meaning indices 0 and 3 for "現行品" and "評価品"
        #create blank image with white background
        image_width, image_height = 300, 250  # Adjust height for extra rows and title
        img = Image.new('RGB', (image_width, image_height), color='white')
        draw = ImageDraw.Draw(img)
        # Define font (adjust the path if needed)
        try:
            font = ImageFont.truetype("msgothic.ttc", 16)  # Change this to a valid font path if needed
        except IOError:
            font = ImageFont.load_default()  # Use default font if arial.ttf is unavailable

        # Title parameters
        title = "【工程能力】"
        title_font = ImageFont.truetype("msgothic.ttc", 24) if not font else font
        title_height = 2  # Height of the title
        # Draw the title
        title_width, _ = draw.textsize(title, font=title_font)
        title_x = (image_width - title_width) // 2  # Center the title horizontally
        draw.text((title_x, 10), title, font=title_font, fill="black")  # Position it near the top
        # Table parameters
        cell_width = 100
        cell_height = 30
        x_offset, y_offset = 50, 50 + title_height  # Starting point for the table (adjusted for title)

        # Red cells list (values to draw in red)

        red_cells = []
        #list_val=[cp_e_data,cpk_e_data,cp_t_data,cpk_t_data]


        if float(cp_t_data) < 1.33:
            red_cells.append(str(cp_t_data))


        if float(cpk_t_data) < 1:
            red_cells.append(str(cpk_t_data))
        def draw_cell(draw, text, x, y, w, h, color="black", merged=False):
                # Draw the cell outline
            draw.rectangle([x, y, x + w, y + h], outline="black", width=2)
            # Draw the text in the center
            text_width, text_height = draw.textsize(text, font=font)
            text_x = x + (w - text_width) // 2
            text_y = y + (h - text_height) // 2
            draw.text((text_x, text_y), text, font=font, fill=color)

            # Draw the table with merged cells and colored text
        for row_idx, row in enumerate(table_data):
            x = x_offset
            y = y_offset + row_idx * cell_height

            # Merge rows if they are specified in merged_cells
            if row_idx in merged_cells:
                draw_cell(draw, row[0], x, y, cell_width * 2, cell_height, merged=True)  # Span two columns
            else:
                # First column is always black
                draw_cell(draw, row[0], x, y, cell_width, cell_height)
                
                # Check if the second column contains a red cell value
                color = "red" if row[1] in red_cells else "black"
                draw_cell(draw, row[1], x + cell_width, y, cell_width, cell_height, color=color)
        img.save(Outputpath)
     
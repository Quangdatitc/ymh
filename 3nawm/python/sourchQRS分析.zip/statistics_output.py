import numpy as np
import math
from scipy import stats
from scipy.stats import f
import statistics
from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN

#受け取ったデータを元に統計値を算出していくクラス
class statistics_data:
    
    #データ数
    def count(self, data):
        count_data = len(data)
        return count_data
        
    #自由度
    def liberty(self, data):
        liberty_data = len(data) - 1
        return liberty_data
        
    #平均
    def average(self, data):
        average_data = statistics.mean(data)
        return average_data
        
    #標準偏差
    def stdev(self, data):
        stdev_data = statistics.stdev(data)
        return stdev_data
        
    #分散
    def variance(self, data):
        variance_data = statistics.variance(data)
        return variance_data
        
    #T値
    def t_value(self, data):
        t_value_data = stats.t.ppf(1-0.025, df=len(data) - 1)
        return t_value_data
        
    #標準誤差
    def stdev_error(self, data):
        stdev_error_data = np.std(data, ddof=1) / np.sqrt(len(data))
        return stdev_error_data
        
    #平均誤差
    def stdev_average(self, data):
        stdev_average_data = (stats.t.ppf(1-0.025, df=len(data) - 1)) * (np.std(data, ddof=1) / np.sqrt(len(data)))
        return stdev_average_data
        
    #上限値
    def upper_limit(self, data):
        upper_limit_data = statistics.mean(data) + (stats.t.ppf(1-0.025, df=len(data) - 1)) * (np.std(data, ddof=1) / np.sqrt(len(data)))
        return upper_limit_data
        
    #下限値
    def lower_limit(self, data):
        lower_limit_data = statistics.mean(data) - (stats.t.ppf(1-0.025, df=len(data) - 1)) * (np.std(data, ddof=1) / np.sqrt(len(data)))
        return lower_limit_data
        
    #差の自由度
    def liberty_of_difference(self, data, data2):
        liberty_of_difference_data = (len(data) - 1) + (len(data2) - 1)
        return liberty_of_difference_data
        
    #平均値の差
    def mean_difference(self, data, data2):
        mean_difference_data = (statistics.mean(data)) - (statistics.mean(data2))
        return mean_difference_data
    
    #T検定:(母分散が等しいと仮定する標準の独立した2標本検定)
    def t_test(self, data, data2):
        t_test_data = stats.ttest_ind(data, data2, equal_var = True, alternative='two-sided')
        return t_test_data
    
    #T値(現状は不使用)
    def t_value2(self, data, data2):
        n1 = len(data)
        n2 = len(data2)
        mean1 = statistics.mean(data)
        mean2 = statistics.mean(data2)
        var1 = stats.tvar(data)
        var2 = stats.tvar(data2)
        t_value_data = (mean1 - mean2) / (np.sqrt(((n1-1)*var1 + (n2-1)*var2)/(n1 + n2 -2)) * np.sqrt(1/n1 + 1/n2))
        print('T値:')
        print(t_value_data)
        
    #F検定:等分散性の検定(現状は不使用)
    def f_test(self, data, data2):
        f_test_data = stats.bartlett(data, data2)
        return f_test_data

    #F検定:等分散性の検定
    def f_test2(self, data, data2):
        #　統計量Fの計算
        v1 = np.var(data, ddof=1)
        v2 = np.var(data2, ddof=1)
        n1 = len(data)
        n2 = len(data2)
        f_value = v1 / v2
        # 帰無仮説が正しい場合にFが従う確率分を生成
        f_frozen = f.freeze(dfn=n1-1, dfd=n2-1)
        # 右側
        p1 = f_frozen.sf(f_value)
        # 左側
        p2 = f_frozen.cdf(f_value)
        # 小さい方の2倍がp値
        p_value = min(p1, p2) * 2
        return f_value, p_value

    #工程間能力CP
    def cp(self, min, max, data):
        cp_data = (max - min) / (6 * (statistics.stdev(data)))
        return cp_data
    
    #工程間能力CPK
    def cpk(self, min, max):
        if min < max:
            cpk_data = min
        else:
            cpk_data = max
            
        return cpk_data
    
    #工程間能力CPK上限
    def max_cpk(self, max, data):
        max_cpk_data = (max - statistics.mean(data)) / (3 * (statistics.stdev(data)))
        return max_cpk_data

    #工程間能力CPK下限
    def min_cpk(self, min, data):
        min_cpk_data = (statistics.mean(data) - min) / (3 * (statistics.stdev(data)))
        return min_cpk_data
    
    #下側信頼限界(信頼区間)
    def confidence_interval(self, data):
        confidence_interval_data = stats.t.interval(alpha = 0.95, df = len(data) - 1, loc = statistics.mean(data), scale = statistics.stdev(data))
        return confidence_interval_data
    
    #上側信頼限界(信頼区間)
    def upper_confidence_interval(self, data):
        #"pt = t.ppf(1 - 0.95 / 2, n - 1)
        confidence_interval_data = (len(data) - 1) * statistics.variance(data) / confidence_interval_data
        return confidence_interval_data
    
    #四捨五入(3桁)
    def round_3off(self, data):
        round_3off_data = Decimal(str(data)).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
        return round_3off_data
    
    #四捨五入(4桁)
    def round_4off(self, data):
        round_4off_data = Decimal(str(data)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        return round_4off_data
    
    #母平均の判定
    def mean_Judgement(self, data1, data2):
        t_statistic_data = self.t_test(data1, data2).statistic 
        t_statistic_data = self.round_3off(t_statistic_data)
        t_statistic_data = -t_statistic_data
        alpha_a = stats.t.ppf(0.975, (len(data1) - 1 + len(data2) - 1))
        alpha_a = self.round_3off(alpha_a)
        alpha_r = stats.t.ppf(0.995, (len(data1) - 1 + len(data2) - 1))
        alpha_r = self.round_3off(alpha_r)
        textC = "【母平均の判定】"
        textA = "仮説H0は有意水準 {}%で棄却されない(t検定: {} < {})"
        textB = "仮説H0は有意水準 {}%で棄却される(t検定: {} > {})"
        r = 1
        a = 5
        if( t_statistic_data < alpha_a):
            str1 = textA.format(a, t_statistic_data, alpha_a)
        else:
            str1 = textB.format(a, t_statistic_data, alpha_a)
            
        if( t_statistic_data < alpha_r):
            str2 = textA.format(r, t_statistic_data, alpha_r)
        else:
            str2 = textB.format(r, t_statistic_data, alpha_r)
            
        mean_Judgement_data = textC+"\n" +str2 + "\n" +  str1
        
        return mean_Judgement_data
    
    #母分散の判定
    def dispersion_Judgement(self, data1, data2):
        f_statistic_data2 = self.f_test2(data1, data2)
        f_statistic_data = self.round_3off(f_statistic_data2[0])
        alpha_a = stats.f.ppf(0.95, len(data1) - 1, len(data2) - 1)
        alpha_a = self.round_3off(alpha_a)
        alpha_r = stats.f.ppf(0.99, len(data1) - 1, len(data2) - 1)
        alpha_r = self.round_3off(alpha_r)
        textC = "【母分散の判定】"
        textA = "仮説H0は有意水準 {}%で棄却されない(F検定: {} < {})"
        textB = "仮説H0は有意水準 {}%で棄却される(F検定: {} > {})"
        r = 1
        a = 5
        if( f_statistic_data < alpha_a):
            str1 = textA.format(a, f_statistic_data, alpha_a)
        else:
            str1 = textB.format(a, f_statistic_data, alpha_a)
            
        if( f_statistic_data < alpha_r):
            str2 = textA.format(r, f_statistic_data, alpha_r)
        else:
            str2 = textB.format(r, f_statistic_data, alpha_r)
            
        dispersion_Judgement_data =textC+"\n"+ str2 + "\n" +  str1
        
        return dispersion_Judgement_data
    
    #階級数を決めるメソッド(スタージェスの公式)
    def sturges_rule(self, data):
        
        return round(1 + math.log2(data))

import openpyxl
import glob
import sys
import os
import importlib
import output_data
importlib.reload(output_data)

e_column = 2
t_column = 3
e_row = 0
t_row = 0
lower_limit_standard = 0
upper_limit_standard = 0
existing_product = []
test_sample = []
output = output_data.outputData()

#指定のフォルダにあるexcelファイルを読み込んでいくクラス
class excel_read_data:
    
    #ファイルを読み込んでデータ処理
    def input(self):
        
        global existing_product, test_sample, e_column, t_column

        strPath = os.getcwd()
        searchFail = os.path.join(strPath, "input", "*.xlsm")
        outputFolder = os.path.join(strPath, "output")
        endFlag = True
        
        #フォルダの存在チェック
        #if os.path.isdir(folderpath):
            #print("フォルダが存在しません")
            
        #エクセルデータ読み込んでデータ件数分の処理するメソッド
        files = glob.glob(searchFail)
        for inputFail in files:
            
            #ここで例外処理
            try:
                wb = openpyxl.load_workbook(inputFail, read_only = True)
                ws = wb["集計表"]          
                #処理開始フラグON
                endFlag = False
                i = 2
                while len(ws.cell(9, i).value) != 0:
                    self.dataSet(ws)
                    outputName = ws.cell(12, e_column).value
                    outputFile = os.path.join(outputFolder, outputName)
                    #フォルダ作成
                    os.mkdir(outputFile)
                    #画像Path作成
                    outputFile = os.path.join(outputFile, outputName)
                    e_column = e_column + 2
                    t_column = t_column + 2
                    i = i + 2
                    #データを統計データにする処理
                    if len(existing_product) == 0:
                        output.testDataCreation(lower_limit_standard, upper_limit_standard, test_sample, outputFile, outputName)
                    # elif len(test_sample) == 0:
                    #     output.existingDataCreation(lower_limit_standard, upper_limit_standard, existing_product, outputFile, outputName)
                    else:
                        output.standardDataCreation(lower_limit_standard, upper_limit_standard, existing_product, test_sample, outputFile, outputName)
                    
            except Exception as e:
                print(e)
                
        if endFlag == True:
            print("読み込むファイルがありません。処理を終了します")
            sys.exit()
    
    
    #1データごとの読み込み処理をするメソッド
    def dataSet(self, ws):
        
        global e_column, e_row, t_column, t_row, lower_limit_standard, upper_limit_standard, existing_product, test_sample
        #初期化
        e_row = 27
        t_row = 27
        lower_limit_standard = 0
        upper_limit_standard = 0
        existing_product = []
        test_sample = []
        
        #既存のリスト作成
        while not ws.cell(e_row, e_column).value is None:
            existing_product.append(ws.cell(e_row, e_column).value)
            e_row = e_row + 1
        
        #評価のリスト作成
        while not ws.cell(t_row, t_column).value is None:
            test_sample.append(ws.cell(t_row, t_column).value)
            t_row = t_row + 1
            
        if ws.cell(9, e_column).value == "締結アバター":
            #検査基準下限読み込み
            lower_limit_standard = ws.cell(17, e_column).value
            #検査基準上限読み込み
            upper_limit_standard = ws.cell(16, e_column).value
        else:
            #規格下限読み込み
            lower_limit_standard = ws.cell(15, e_column).value
            #規格上限読み込み
            upper_limit_standard = ws.cell(14, e_column).value
import importlib
import statistics_output
importlib.reload(statistics_output)
import data_table
importlib.reload(data_table)
import pandas as pd
from matplotlib.font_manager import FontProperties
from decimal import Decimal,ROUND_HALF_UP
fp = FontProperties(fname = r"C:/WINDOWS/Fonts/msgothic.ttc",size = 20 )
calculation = statistics_output.statistics_data()
image = data_table.image_fail_output()
output = statistics_output.statistics_data()

#受け取ったデータを別のクラスに渡して処理をするクラス
class outputData:
    
    #通常の工程能力の作成
    def standardDataCreation(self, lower_limit_standard, upper_limit_standard, existing_product, test_sample, outputFile, outputName):
        #dong bien nay de tinh toan o bang
        count_e_data, average_e_data, variance_e_data, stdev_e_data, liberty_e_data, lower_limit_e_data, upper_limit_e_data = self.e_basicStatistics(existing_product)
        cp_e_data, max_cpk_e_data, min_cpk_e_data, cpk_e_data = self.eCPK_basicStatistics(lower_limit_standard, upper_limit_standard, existing_product)
        count_t_data, average_t_data, variance_t_data, stdev_t_data, liberty_t_data, lower_limit_t_data, upper_limit_t_data = self.t_basicStatistics(test_sample)
        cp_t_data, max_cpk_t_data, min_cpk_t_data, cpk_t_data = self.tCPK_basicStatistics(lower_limit_standard, upper_limit_standard, test_sample)
        
        #母分散の比
        #f_test_data = calculation.f_test(existing_product, test_sample)                        #F検定
        f_value, p_value = calculation.f_test2(existing_product, test_sample)                   #F検定S
        f_value2, p_value = calculation.f_test2(test_sample, existing_product)                  #F検定
        f_test_Judgement = calculation.dispersion_Judgement(test_sample, existing_product)      #判定
        #母平均の差
        mean_difference_data = calculation.mean_difference(existing_product, test_sample)                #平均値の差
        liberty_of_difference_data = calculation.liberty_of_difference(existing_product, test_sample)    #差の自由度
        t_pvalue_data = calculation.t_test(existing_product, test_sample).pvalue                         #T検定(P値片側)
        t_statistic_data = calculation.t_test(existing_product, test_sample).statistic                   #統計量t0
        t_test_Judgement = calculation.mean_Judgement(existing_product, test_sample)                     #判定
        
        fTestList = [
            ["変数名", "既存", "信頼率", "95%"],
            ["データ数", count_e_data, "下限値", "上限値"],
            ["平均値", calculation.round_3off(average_e_data), calculation.round_3off(lower_limit_e_data), calculation.round_3off(upper_limit_e_data)],
            ["分散", calculation.round_4off(variance_e_data), "", ""],#"下側信頼限界", "上側信頼限界"が入る
            ["標準偏差", calculation.round_4off(stdev_e_data), "", ""],
            ["自由度", liberty_e_data, "", ""],
            ["変数名", "評価", "", ""],
            ["データ数", count_t_data, "下限値", "上限値"],
            ["平均値", calculation.round_3off(average_t_data), calculation.round_3off(lower_limit_t_data), calculation.round_3off(upper_limit_t_data)],
            ["分散", calculation.round_4off(variance_t_data), "", ""],
            ["標準偏差", calculation.round_4off(stdev_t_data), "", ""],
            ["自由度", liberty_t_data, "", ""],
            ["分散の比", calculation.round_4off(f_value), "", ""],
            ["帰無仮説H0", "σ1^2 = σ2^2", "", ""],
            ["対立仮説H1", "σ1^2 < σ2^2", "", ""],
            ["統計量F", calculation.round_3off(f_value2), "p値(上側)", calculation.round_3off(1 - p_value / 2)]
        ]
        tTestList = [
            ["変数名", "既存", "信頼率", "95%"],
            ["データ数", count_e_data, "下限値", "上限値"],
            ["平均値", calculation.round_3off(average_e_data), calculation.round_3off(lower_limit_e_data), calculation.round_3off(upper_limit_e_data)],
            ["分散", calculation.round_4off(variance_e_data), "", ""],
            ["標準偏差", calculation.round_4off(stdev_e_data), "", ""],
            ["自由度", liberty_e_data, "", ""],
            ["変数名", "評価", "", ""],
            ["データ数", count_t_data, "下限値", "上限値"],
            ["平均値", calculation.round_3off(average_t_data), calculation.round_3off(lower_limit_t_data), calculation.round_3off(upper_limit_t_data)],
            ["分散", calculation.round_4off(variance_t_data), "", ""],
            ["標準偏差", calculation.round_4off(stdev_t_data), "", ""],
            ["自由度", liberty_t_data, "", ""],
            ["平均値の差", calculation.round_3off(mean_difference_data), "", ""],
            ["差の自由度", liberty_of_difference_data, "", ""],
            ["母標準偏差", "未知", "", ""],
            ["帰無仮説H0", "μ1 = μ2", "", ""],
            ["対立仮説H1", "μ1 ≠ μ2", "", ""],
            ["", "有意水準  1%", "有意水準  5%", ""],
            ["検定方法", "t検定", "t検定", ""],
            ["統計量 t0", calculation.round_3off(t_statistic_data), calculation.round_3off(t_statistic_data), ""],
            ["検定の自由度", liberty_e_data + liberty_t_data, liberty_e_data + liberty_t_data, ""],
            ["p値(両側)", calculation.round_3off(t_pvalue_data), calculation.round_3off(t_pvalue_data), ""]
        ]

        df = pd.DataFrame(fTestList)
        df_t=pd.DataFrame(tTestList)
        outputPath = outputFile + "_母分散の比.png"
        #image.table_display(df, outputPath, f_test_Judgement)
        image.table_display(existing_product,
                                    test_sample,
                                    average_e_data,
                                    stdev_e_data,
                                    cp_e_data,
                                    cpk_e_data,
                                    average_t_data,
                                    stdev_t_data,
                                    cp_t_data,
                                    cpk_t_data,
                                    lower_limit_standard,
                                    upper_limit_standard,
                                    outputPath,
                                    outputName,
                                    df, f_test_Judgement,df_t,t_test_Judgement)

        """df = pd.DataFrame(tTestList)
        outputPath = outputFile + "_母平均の差.png"
        #image.table_display(df, outputPath, t_test_Judgement)
        image.table_display(existing_product,
                                    test_sample,
                                    average_e_data,
                                    stdev_e_data,
                                    cp_e_data,
                                    cpk_e_data,
                                    average_t_data,
                                    stdev_t_data,
                                    cp_t_data,
                                    cpk_t_data,
                                    lower_limit_standard,
                                    upper_limit_standard,
                                    outputPath,
                                    outputName,
                                    df, t_test_Judgement)"""
        #create 工程能力　when 上限=0 or 下限 =0
        if Decimal(lower_limit_standard).quantize(Decimal("0.00"), rounding=ROUND_HALF_UP)==0.00:
            outputPath = outputFile + "工程能力.png"
            image.capability_table_top(max_cpk_e_data,max_cpk_t_data,outputPath)
            
        elif Decimal(upper_limit_standard).quantize(Decimal("0.00"), rounding=ROUND_HALF_UP)==0.00:
            outputPath = outputFile + "工程能力.png"
            image.capability_table_bot(min_cpk_e_data,min_cpk_t_data,outputPath)
        else:
            outputPath = outputFile + "工程能力.png"
            image.capability_table(cp_e_data,
                                        cpk_e_data,
                                        cp_t_data,
                                        cpk_t_data,
                                        outputPath)
        
    #既存工程能力の作成
    def existingDataCreation(self, lower_limit_standard, upper_limit_standard, existing_product, outputFile, outputName):
        
        count_e_data, average_e_data, variance_e_data, stdev_e_data, liberty_e_data, lower_limit_e_data, upper_limit_e_data = self.e_basicStatistics(existing_product)
        cp_e_data, max_cpk_e_data, min_cpk_e_data, cpk_e_data = self.eCPK_basicStatistics(lower_limit_standard, upper_limit_standard, existing_product)
        outputPath = outputFile + "_ヒストグラム.png"
        image.existing_histogramDisplay(existing_product,
                                average_e_data,
                                stdev_e_data,
                                cp_e_data,
                                cpk_e_data,
                                lower_limit_standard,
                                upper_limit_standard,
                                outputPath,
                                outputName)
        
    #評価工程能力の作成
    def testDataCreation(self, lower_limit_standard, upper_limit_standard, test_sample, outputFile, outputName):
        
        count_t_data, average_t_data, variance_t_data, stdev_t_data, liberty_t_data, lower_limit_t_data, upper_limit_t_data = self.t_basicStatistics(test_sample)
        cp_t_data, max_cpk_t_data, min_cpk_t_data, cpk_t_data = self.tCPK_basicStatistics(lower_limit_standard, upper_limit_standard, test_sample)
        outputPath = outputFile + "_ヒストグラム片側.png"
        image.test_histogramDisplay(test_sample,
                                average_t_data,
                                stdev_t_data,
                                cp_t_data,
                                cpk_t_data,
                                lower_limit_standard,
                                upper_limit_standard,
                                outputPath,
                                outputName)
        if Decimal(lower_limit_standard).quantize(Decimal("0.00"), rounding=ROUND_HALF_UP)==0.00:
            outputPath = outputFile + "工程能力片側.png"
            image.katagawa_table_top(max_cpk_t_data,outputPath)
            
        elif Decimal(upper_limit_standard).quantize(Decimal("0.00"), rounding=ROUND_HALF_UP)==0.00:
            outputPath = outputFile + "工程能力片側.png"
            image.katagawa_table_bot(min_cpk_t_data,outputPath)
        else:
            outputPath = outputFile + "工程能力片側.png"
            image.katagawa_table(
                                        cp_t_data,
                                        cpk_t_data,
                                        outputPath)
        
    #既存基礎統計値の作成
    def e_basicStatistics(self, existing_product):
        
        count_e_data = calculation.count(existing_product)           #データ数
        average_e_data = calculation.average(existing_product)       #平均
        variance_e_data = calculation.variance(existing_product)     #分散
        stdev_e_data = calculation.stdev(existing_product)           #標準偏差
        liberty_e_data = calculation.liberty(existing_product)       #自由度
        lower_limit_e_data = calculation.lower_limit(existing_product) #下限値
        upper_limit_e_data = calculation.upper_limit(existing_product) #上限値
        
        return count_e_data, average_e_data, variance_e_data, stdev_e_data, liberty_e_data, lower_limit_e_data, upper_limit_e_data
    
    #既存CPK基礎統計値の作成
    def eCPK_basicStatistics(self, lower_limit_standard, upper_limit_standard, existing_product):
        
        #工程間能力(既存)
        cp_e_data = calculation.cp(lower_limit_standard, upper_limit_standard, existing_product)
        max_cpk_e_data = calculation.max_cpk(upper_limit_standard, existing_product)
        min_cpk_e_data = calculation.min_cpk(lower_limit_standard, existing_product)
        cpk_e_data = calculation.cpk(min_cpk_e_data, max_cpk_e_data)
        
        return cp_e_data, max_cpk_e_data, min_cpk_e_data, cpk_e_data
        
    #評価基礎統計値の作成
    def t_basicStatistics(self, test_sample):
        
        count_t_data = calculation.count(test_sample)            #データ数
        average_t_data = calculation.average(test_sample)        #平均
        variance_t_data = calculation.variance(test_sample)      #分散
        stdev_t_data = calculation.stdev(test_sample)            #標準偏差
        liberty_t_data = calculation.liberty(test_sample)        #自由度
        lower_limit_t_data = calculation.lower_limit(test_sample) #下限値
        upper_limit_t_data = calculation.upper_limit(test_sample) #上限値
        
        return count_t_data, average_t_data, variance_t_data, stdev_t_data, liberty_t_data, lower_limit_t_data, upper_limit_t_data
        
    #評価CPK基礎統計値の作成
    def tCPK_basicStatistics(self, lower_limit_standard, upper_limit_standard, test_sample):
        
        #工程間能力(生試)
        cp_t_data = calculation.cp(lower_limit_standard, upper_limit_standard, test_sample)
        max_cpk_t_data = calculation.max_cpk(upper_limit_standard, test_sample)
        min_cpk_t_data = calculation.min_cpk(lower_limit_standard, test_sample)
        cpk_t_data = calculation.cpk(min_cpk_t_data, max_cpk_t_data)
        
        return cp_t_data, max_cpk_t_data, min_cpk_t_data, cpk_t_data
    
